﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="InvoiceView.xaml.cs" company="">
//   
// </copyright>
// <summary>
//   Interaction logic for "InvoiceView.xaml"
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace FH.Views
{
    /// <summary>
    /// Interaction logic for "InvoiceView.xaml"
    /// </summary>
    public partial class InvoiceView
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InvoiceView"/> class.
        /// </summary>
        public InvoiceView()
        {
            InitializeComponent();
        }
    }
}
