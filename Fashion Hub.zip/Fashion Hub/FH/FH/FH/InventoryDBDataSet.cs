﻿namespace FH {
    
    
    public partial class InventoryDBDataSet {
    }
}

namespace FH.InventoryDBDataSetTableAdapters {
    
    
    public partial class GetInventoryDataTableAdapter {
    }
}
